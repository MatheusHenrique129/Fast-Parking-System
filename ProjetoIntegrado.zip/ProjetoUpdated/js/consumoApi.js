'use strict';

const nomeCliente = document.getElementById('nomeCliente');

const placaCarro = document.getElementById('placaCarro');

const corCarro = document.getElementById('corCarro');

const botaoCadastrar = document.getElementById('buttonCadastrar');

const modalComprovante = document.getElementById('modalComprovante');


function criarCliente( cliente ) {
    const url = 'http://localhost/Matheus/ProjetoUpdated-main/ProjetoUpdated/ProjetoIntegrado/api/api.php/clientes';
    const options = {
      method: 'POST',
      headers: {

        'Content-Type':'application/json'

      },
      body: JSON.stringify(cliente)
     
    };
  
  fetch(url, options)
}

let cliente;
const dadosCliente = () => {
  cliente = {
    "nomeCliente": nomeCliente.value,
    "placa": placaCarro.value,
    "cor": corCarro.value
  }
  criarCliente(cliente)
  location.reload()
};



const getClientes = () =>{
  const url = `http://localhost/Matheus/ProjetoUpdated-main/ProjetoUpdated/ProjetoIntegrado/api/api.php/clientes`;  
  fetch(url).then(response => response.json())
            .then(data =>  repeticao(data));    
}

const insertToElement = (element) => {

  const tr = document.createElement('tr');

  tr.classList.add('colunas');

  tr.innerHTML = `
  
    <td class="info">${element.nomeCliente}</td>
    <td class="info">${element.placa}</td>
    <td class="info">${element.cor}</td>
    <td class="info">${element.horarioEntrada}</td>
    <td class="info">
    <div class="buton-options">
      <input type="submit" name="btnCadastrar" value="Excluir" onclick="excluirCliente(${element.idCliente})" class="excluir-cliente">
    </div>
    <div class="buton-options">
      <input onclick="chamaComprovante()" type="submit" name="btnCadastrar" value="Gerar Comprovante" id="botaoExcluir" class="emitir-comprovante">
    </div>
    
    </td>
    `;

  return tr;
 
}


const repeticao = (data) => {

  const container = document.getElementById('tbl-Clientes');
  
  data.forEach(element => {
    container.appendChild(insertToElement(element));

  });

}

function sair() {
  window.history.back();
}

function excluirCliente(idCliente){

    const url = `http://localhost/Matheus/ProjetoUpdated-main/ProjetoUpdated/ProjetoIntegrado/api/api.php/clientes/${idCliente}`;
    const options = {
      method: 'DELETE',
      headers: {

        'Content-Type':'application/json'

      },
    }
    fetch(url, options)
    location.reload()

}

function updateCliente(){

  const url = `http://localhost/Matheus/ProjetoUpdated-main/ProjetoUpdated/ProjetoIntegrado/api/api.php/clientes/${idCliente}`;
  const options = {
    method: 'PUT',
    headers: {

      'Content-Type':'application/json'

    },
  }

  fetch(url, options).then(data => emitirComprovante(data))

}

function emitirComprovante(){


}


botaoCadastrar.addEventListener('click', dadosCliente);
getClientes();
