function chamaModal(){
    let modal = document.querySelector('.containerModal');

    modal.style.display = 'block';
    
}

function fechaModal(){
    let modal = document.querySelector('.containerModal');

    modal.style.display = 'none';

    
}

function chamaComprovante(){
    let modalComprovante = document.querySelector('.containerModalComprovante');
    
    modalComprovante.style.display = 'block';
}

function fechaComprovante(){
    let modalComprovante = document.querySelector('.containerModalComprovante');
    
    modalComprovante.style.display = 'none';

}